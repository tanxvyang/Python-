from distutils.core import setup

setup(
    name   ="tan-sanitize",
    version     =  '1.2.0',
    py_modules = ['tan_sanitize'],
    author  ='tanxvyang',
    author_email='1173195180@qq.com',
    url='',
    description='A simple printer of sanitize time data lists'
)
