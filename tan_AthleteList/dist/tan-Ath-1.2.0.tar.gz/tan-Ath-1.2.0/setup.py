from distutils.core import setup

setup(
    name   ="tan-Ath",
    version     =  '1.2.0',
    py_modules = ['tan_AthleteList'],
    author  ='tanxvyang',
    author_email='1173195180@qq.com',
    url='',
    description='一个派生(继承)了内置类 list 的AthleteLIst面向对象类,可以处理选手信息,使用__inlit__定制对象的初始状态'
)
